package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Divide {

	@Test
	void test() {
		JunitTesting test = new JunitTesting();
		double output = test.divide(60,20);
		assertEquals(3, output);
	}

}
