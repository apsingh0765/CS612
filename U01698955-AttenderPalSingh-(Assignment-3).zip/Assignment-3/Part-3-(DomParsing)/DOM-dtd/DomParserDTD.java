package dtd;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.SchemaFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

	
public class DomParserDTD{
public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
DocumentBuilder db = f.newDocumentBuilder();
// Load the input XML document, parse it and return an instance of the Document class.
Document document = db.parse("cellphones.xml");
boolean flag=true;
try {
	validate1("cellphones.xml");
	
	
}
catch(ParserConfigurationException e) {System.out.println("parserexception");flag=false;}
catch(FileNotFoundException e) {System.out.println("fileexception");flag=false;}
catch(SAXException e) {System.out.println("saxexception");flag=false;}
catch(IOException e) {System.out.println("ioexception");flag=false;}

System.out.println("xml file is valid: "+flag);

NodeList nodeList = document.getElementsByTagName("phone");
for (int i = 0; i < nodeList.getLength(); i++) {
Node n = nodeList.item(i);
if (n.getNodeType() == Node.ELEMENT_NODE) {
Element elem = (Element) n;
// Get the value of the ID attribute.
String ID = elem.getAttribute("ID");
NodeList list=elem.getChildNodes();
for(int j=0;j<list.getLength();j++){
Node n1 = list.item(j);
if(n1.getNodeType()==Node.ELEMENT_NODE){
Element name=(Element) n1;
System.out.println("cellphone "+ID+":"+name.getTagName()+"-"+name.getTextContent());
      }
	}
  }
}
}         
public static void validate1(String xmlfile) throws FileNotFoundException, SAXException, IOException, ParserConfigurationException{
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = factory.newDocumentBuilder();

factory.setValidating(true);
// Load the input XML document, parse it and return an instance of the Document class.
builder.parse(new FileInputStream(xmlfile));
}

}
	


	
