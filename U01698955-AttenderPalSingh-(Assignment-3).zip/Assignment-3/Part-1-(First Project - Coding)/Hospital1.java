public class Hospital1
{
	public static void main(String[]args)
	{
		HospitalEmployee vito = new HospitalEmployee("Vito",123);
		Doctor michael = new Doctor("Michael",234,"Heart");
		Surgeon vincent = new Surgeon("Vincent",645,"Brain",true);
		Nurse sonny = new Nurse("Sonny",789,6);
		
		System.out.println(vito);
		System.out.println(michael);
		System.out.println(vincent);
		System.out.println(sonny);
		
		vito.work();
		michael.work();
		vincent.work();
		sonny.work();
	}
}

class HospitalEmployee
{
	protected String name;
	protected int number;
	public HospitalEmployee (String empName, int empNumber)
	{
		name=empName;
		number=empNumber;
	}
	public void setName(String empName)
	{
		name=empName;
	}
	public void setNumber (int empNumber)
	{
		number=empNumber;
	}
	public String getName()
	{
		return name;
	}
	public int getNumber()
	{
		return number;
	}
	public String toString()
	{
		return name+ "\t" +number;
	}
	public void work()
	{
		System.out.println(name+" works for the hospital");
	}
}

class Doctor extends HospitalEmployee
{
	protected String specialty;
	public void setName(String empName)
	{
		name=empName;
	}
	public Doctor (String empName, int empNumber, String special)
	{
		super(empName,empNumber);
		specialty = special;
	}
	public void setSpeciality(String special)
	{
		specialty = special;
	}
	public String getSpecialty()
	{
		return specialty;
	}
	public String toString()
	{
		return super.toString()+ "\t" + specialty;
	}	
	public void work()
	{
		System.out.println(name+" works for the hospital. "+name+" is a(n) "+specialty+" doctor.");
	}
}

class Surgeon extends Doctor
{
	protected boolean operating;
	public void setName(String empName)
	{
		name=empName;
	}
	public Surgeon(String empName, int empNumber, String special, boolean isOper)
	{
		super(empName, empNumber, special);
		operating = isOper;
	}
	public void setIsOperating(boolean isOper)
	{
		operating = isOper;
	}
	public boolean getIsOperating()
	{
		return operating;
	}
	public String toString()
	{
		return super.toString()+ "\tOperating: "+operating;
	}
	public void work()
	{
		System.out.println(name+" works for the hospital. "+name+" is operating now.");
	}
}


class Nurse extends HospitalEmployee
{
	protected int numPatients;
	public void setName(String empName)
	{
		name=empName;
	}
	public Nurse(String empName, int empNumber, int numPat)
	{
		super(empName,empNumber);
		numPatients=numPat;
	}
	public void setNumPatients(int pat)
	{
		numPatients=pat;
	}
	public int getNumPatients()
	{
		return numPatients;
	}
	public String toString()
	{
		return super.toString()+" has "+numPatients+ " patients.";
	}
	public void work()
	{
		System.out.println(name+" works for the hospital. "+name+" is a nurse with "+numPatients+" patients.");
	}

}
